"""Static local viewer assets."""
